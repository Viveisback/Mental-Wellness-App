import { useState } from "react";
import { WelcomeSection } from "./components/WelcomeSection";
import { Assessment } from "./components/Assessment";
import { Dashboard } from "./components/Dashboard";
import { AIChat } from "./components/AIChat";
import { CrisisSupport } from "./components/CrisisSupport";

type AppState = 'welcome' | 'assessment' | 'dashboard' | 'chat' | 'crisis';

interface AssessmentResults {
  totalScore: number;
  riskLevel: 'low' | 'moderate' | 'high';
  categories: {
    anxiety: number;
    depression: number;
    stress: number;
  };
}

export default function App() {
  const [currentState, setCurrentState] = useState<AppState>('welcome');
  const [assessmentResults, setAssessmentResults] = useState<AssessmentResults | null>(null);

  const handleGetStarted = () => {
    setCurrentState('assessment');
  };

  const handleAssessmentComplete = (results: AssessmentResults) => {
    setAssessmentResults(results);
    setCurrentState('dashboard');
  };

  const handleStartChat = () => {
    setCurrentState('chat');
  };

  const handleCrisisHelp = () => {
    setCurrentState('crisis');
  };

  const handleBackToDashboard = () => {
    setCurrentState('dashboard');
  };

  const handleBackToWelcome = () => {
    setCurrentState('welcome');
  };

  switch (currentState) {
    case 'welcome':
      return <WelcomeSection onGetStarted={handleGetStarted} />;
    
    case 'assessment':
      return (
        <Assessment 
          onComplete={handleAssessmentComplete}
          onBack={handleBackToWelcome}
        />
      );
    
    case 'dashboard':
      if (!assessmentResults) {
        setCurrentState('welcome');
        return null;
      }
      return (
        <Dashboard
          assessmentResults={assessmentResults}
          onStartChat={handleStartChat}
          onCrisisHelp={handleCrisisHelp}
        />
      );
    
    case 'chat':
      return <AIChat onBack={handleBackToDashboard} />;
    
    case 'crisis':
      return <CrisisSupport onBack={handleBackToDashboard} />;
    
    default:
      return <WelcomeSection onGetStarted={handleGetStarted} />;
  }
}