import { useState, useRef, useEffect } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card } from "./ui/card";
import { Avatar } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { ArrowLeft, Send, Heart, Shield, Users } from "lucide-react";

interface AIChatProps {
  onBack: () => void;
}

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  suggestions?: string[];
}

export function AIChat({ onBack }: AIChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: "Hello! I'm Alex, your AI wellness companion. I'm here to listen, support, and help you navigate your mental health journey. Everything we discuss is completely confidential. How are you feeling today?",
      sender: 'ai',
      timestamp: new Date(),
      suggestions: [
        "I'm feeling anxious",
        "I've been stressed lately",
        "I'm having trouble sleeping",
        "I feel overwhelmed"
      ]
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateAIResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('anxious') || message.includes('anxiety')) {
      return "I understand that anxiety can feel overwhelming. It's completely normal to experience these feelings, and you're brave for reaching out. Can you tell me more about what's been triggering your anxiety lately? Sometimes talking through specific situations can help us understand patterns and develop coping strategies together.";
    }
    
    if (message.includes('stress') || message.includes('overwhelmed')) {
      return "Stress can really weigh on us, especially when we feel like we're juggling too much. You're not alone in feeling this way. Let's take a moment to break things down. What are the main sources of stress in your life right now? Sometimes identifying specific stressors can help us create a plan to manage them more effectively.";
    }
    
    if (message.includes('sleep') || message.includes('tired')) {
      return "Sleep issues can really impact how we feel during the day. It's great that you're recognizing this connection. Poor sleep often goes hand in hand with stress and anxiety. Have you noticed any patterns in your sleep difficulties? For example, trouble falling asleep, waking up frequently, or waking up too early?";
    }
    
    if (message.includes('sad') || message.includes('depressed') || message.includes('down')) {
      return "Thank you for sharing something so personal with me. Feeling sad or down is a very human experience, and it takes courage to acknowledge these feelings. You don't have to go through this alone. Can you help me understand what's been contributing to these feelings? Is this something recent or have you been feeling this way for a while?";
    }
    
    if (message.includes('lonely') || message.includes('alone')) {
      return "Loneliness can be really painful, and I want you to know that reaching out here shows incredible strength. Even when we feel isolated, there are people and resources available to support you. What would connection look like for you right now? Sometimes starting small, like this conversation, can be the first step toward feeling more connected.";
    }
    
    // General supportive responses
    const responses = [
      "Thank you for sharing that with me. Your feelings are valid, and I'm here to support you through this. Can you tell me more about what's been on your mind?",
      "I appreciate you being open with me. It sounds like you're going through something challenging. What would be most helpful for you to talk about right now?",
      "That sounds really difficult. You're showing a lot of strength by reaching out for support. How long have you been feeling this way?",
      "I'm glad you felt comfortable sharing that with me. Your mental health matters, and you deserve support. What do you think would help you feel better right now?"
    ];
    
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const handleSend = async (messageText?: string) => {
    const text = messageText || inputValue.trim();
    if (!text) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: text,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");
    setIsTyping(true);

    // Simulate AI thinking time
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: generateAIResponse(text),
        sender: 'ai',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1500 + Math.random() * 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    handleSend(suggestion);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-purple-900">
      <div className="container mx-auto max-w-4xl h-screen flex flex-col">
        {/* Header */}
        <div className="p-4 border-b bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" onClick={onBack}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <div className="flex items-center space-x-3">
                <Avatar className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center text-white">
                  🤖
                </Avatar>
                <div>
                  <h2 className="text-lg">Alex - AI Counselor</h2>
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span>Online & Ready to Help</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="text-xs">
                <Shield className="w-3 h-3 mr-1" />
                Confidential
              </Badge>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-3xl ${message.sender === 'user' ? 'order-2' : 'order-1'}`}>
                <Card className={`p-4 ${
                  message.sender === 'user' 
                    ? 'bg-blue-500 text-white ml-12' 
                    : 'bg-white dark:bg-gray-800 mr-12'
                }`}>
                  <p className="whitespace-pre-wrap">{message.content}</p>
                  <div className="text-xs opacity-70 mt-2">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </Card>
                
                {message.suggestions && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {message.suggestions.map((suggestion, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        onClick={() => handleSuggestionClick(suggestion)}
                        className="text-sm"
                      >
                        {suggestion}
                      </Button>
                    ))}
                  </div>
                )}
              </div>
              
              <Avatar className={`w-8 h-8 ${message.sender === 'user' ? 'order-1 ml-3' : 'order-2 mr-3'}`}>
                {message.sender === 'user' ? '👤' : '🤖'}
              </Avatar>
            </div>
          ))}
          
          {isTyping && (
            <div className="flex justify-start">
              <div className="max-w-3xl order-1">
                <Card className="p-4 bg-white dark:bg-gray-800 mr-12">
                  <div className="flex items-center space-x-2">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                    <span className="text-sm text-muted-foreground">Alex is typing...</span>
                  </div>
                </Card>
              </div>
              <Avatar className="w-8 h-8 order-2 mr-3">🤖</Avatar>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Privacy Notice */}
        <div className="px-4 py-2 bg-green-50 dark:bg-green-900/20 border-t">
          <div className="flex items-center justify-center space-x-4 text-sm text-green-700 dark:text-green-300">
            <Heart className="w-4 h-4" />
            <span>This conversation is private and encrypted</span>
            <Shield className="w-4 h-4" />
            <span>Your data is never shared</span>
            <Users className="w-4 h-4" />
            <span>Crisis support available 24/7</span>
          </div>
        </div>

        {/* Input */}
        <div className="p-4 border-t bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
          <div className="flex items-center space-x-2">
            <Input
              ref={inputRef}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Share what's on your mind... I'm here to listen."
              className="flex-1"
              disabled={isTyping}
            />
            <Button 
              onClick={() => handleSend()} 
              disabled={!inputValue.trim() || isTyping}
              size="sm"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2 text-center">
            If you're in crisis, please reach out to emergency services or call a crisis hotline immediately.
          </p>
        </div>
      </div>
    </div>
  );
}