import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Heart, Shield, Users } from "lucide-react";

interface WelcomeSectionProps {
  onGetStarted: () => void;
}

export function WelcomeSection({ onGetStarted }: WelcomeSectionProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-purple-900">
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="mb-6 text-4xl md:text-6xl bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            MindSpace
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
            Your safe, confidential space for mental wellness. We're here to support you on your journey, without judgment.
          </p>
          <Button onClick={onGetStarted} size="lg" className="px-8 py-3">
            Start Your Journey
          </Button>
        </div>

        <div className="relative mb-16">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1560134928-56b72fa51aaf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx8MTc1ODA5NTkxM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Peaceful nature scene"
            className="w-full h-64 md:h-96 object-cover rounded-2xl shadow-2xl"
          />
          <div className="absolute inset-0 bg-black/20 rounded-2xl flex items-center justify-center">
            <div className="text-center text-white">
              <h2 className="text-2xl md:text-3xl mb-4">You're Not Alone</h2>
              <p className="text-lg opacity-90">Every step forward matters, no matter how small</p>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <Card className="p-8 text-center hover:shadow-lg transition-all">
            <Shield className="w-12 h-12 text-blue-500 mx-auto mb-4" />
            <h3 className="text-xl mb-4">100% Confidential</h3>
            <p className="text-muted-foreground">
              Your privacy is our priority. All conversations and data are encrypted and secure.
            </p>
          </Card>
          
          <Card className="p-8 text-center hover:shadow-lg transition-all">
            <Heart className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <h3 className="text-xl mb-4">Empathetic AI</h3>
            <p className="text-muted-foreground">
              Our AI is trained to understand and respond with genuine care and empathy.
            </p>
          </Card>
          
          <Card className="p-8 text-center hover:shadow-lg transition-all">
            <Users className="w-12 h-12 text-green-500 mx-auto mb-4" />
            <h3 className="text-xl mb-4">Community Support</h3>
            <p className="text-muted-foreground">
              Connect with others who understand your journey in a safe, moderated environment.
            </p>
          </Card>
        </div>

        <div className="text-center bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900 dark:to-blue-900 rounded-2xl p-8">
          <h2 className="text-2xl mb-4">Breaking the Stigma Together</h2>
          <p className="text-muted-foreground max-w-3xl mx-auto mb-6">
            Mental health is just as important as physical health. There's no shame in seeking support, 
            asking questions, or taking time to care for your mental wellness. You're taking a brave step.
          </p>
          <div className="flex flex-wrap justify-center gap-4 text-sm">
            <span className="bg-white dark:bg-gray-800 px-4 py-2 rounded-full">Anxiety Support</span>
            <span className="bg-white dark:bg-gray-800 px-4 py-2 rounded-full">Depression Resources</span>
            <span className="bg-white dark:bg-gray-800 px-4 py-2 rounded-full">Stress Management</span>
            <span className="bg-white dark:bg-gray-800 px-4 py-2 rounded-full">Crisis Support</span>
            <span className="bg-white dark:bg-gray-800 px-4 py-2 rounded-full">Self-Care Tools</span>
          </div>
        </div>
      </div>
    </div>
  );
}