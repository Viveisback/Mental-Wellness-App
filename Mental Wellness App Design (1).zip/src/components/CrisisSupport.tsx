import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { ArrowLeft, Phone, MessageSquare, ExternalLink, Clock, MapPin } from "lucide-react";

interface CrisisSupportProps {
  onBack: () => void;
}

export function CrisisSupport({ onBack }: CrisisSupportProps) {
  const crisisResources = [
    {
      name: "National Suicide Prevention Lifeline",
      phone: "988",
      description: "24/7 crisis support for suicidal thoughts",
      available: "24/7",
      type: "Crisis Hotline"
    },
    {
      name: "Crisis Text Line",
      phone: "Text HOME to 741741",
      description: "24/7 crisis counseling via text message",
      available: "24/7",
      type: "Text Support"
    },
    {
      name: "Teen Line",
      phone: "800-852-8336",
      description: "Teens helping teens with confidential support",
      available: "6 PM - 10 PM PST",
      type: "Teen Support"
    },
    {
      name: "The Trevor Project",
      phone: "1-866-488-7386",
      description: "24/7 crisis support for LGBTQ+ youth",
      available: "24/7",
      type: "LGBTQ+ Support"
    }
  ];

  const localResources = [
    {
      name: "Mobile Crisis Team",
      description: "Emergency mental health response team",
      action: "Call 911 or local emergency services"
    },
    {
      name: "Emergency Room",
      description: "Immediate medical and psychiatric care",
      action: "Visit nearest hospital emergency department"
    },
    {
      name: "Crisis Stabilization Unit",
      description: "Short-term intensive mental health support",
      action: "Contact your local mental health center"
    }
  ];

  const copingStrategies = [
    {
      title: "Grounding Technique (5-4-3-2-1)",
      description: "5 things you see, 4 you hear, 3 you touch, 2 you smell, 1 you taste"
    },
    {
      title: "Deep Breathing",
      description: "Breathe in for 4, hold for 4, breathe out for 6. Repeat."
    },
    {
      title: "Safe Person",
      description: "Call or text someone you trust - a friend, family member, or counselor"
    },
    {
      title: "Safe Space",
      description: "Go to a place where you feel secure and comfortable"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 dark:from-gray-900 dark:to-red-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button variant="ghost" onClick={onBack} className="mb-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          
          <div className="text-center mb-6">
            <h1 className="text-3xl mb-4 text-red-700 dark:text-red-400">Crisis Support</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              If you're in immediate danger or having thoughts of self-harm, please reach out for help right now. 
              You're not alone, and support is available 24/7.
            </p>
          </div>

          {/* Emergency Alert */}
          <Card className="p-6 bg-red-100 border-red-300 dark:bg-red-900/30 dark:border-red-700 mb-8">
            <div className="text-center">
              <h2 className="text-xl mb-4 text-red-800 dark:text-red-300">
                🚨 If this is a life-threatening emergency, call 911 immediately
              </h2>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="bg-red-600 hover:bg-red-700">
                  <Phone className="w-5 h-5 mr-2" />
                  Call 911
                </Button>
                <Button size="lg" variant="outline" className="border-red-300 text-red-700 hover:bg-red-50">
                  <Phone className="w-5 h-5 mr-2" />
                  Call 988 - Suicide Prevention
                </Button>
              </div>
            </div>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Crisis Hotlines */}
          <div className="space-y-6">
            <Card className="p-6">
              <h2 className="text-xl mb-6 flex items-center">
                <Phone className="w-5 h-5 mr-2" />
                Crisis Hotlines & Text Support
              </h2>
              
              <div className="space-y-4">
                {crisisResources.map((resource, index) => (
                  <div key={index} className="p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-medium">{resource.name}</h3>
                      <Badge variant="outline">{resource.type}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{resource.description}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Clock className="w-4 h-4 mr-1" />
                        {resource.available}
                      </div>
                      <Button size="sm" className="bg-green-600 hover:bg-green-700">
                        <Phone className="w-4 h-4 mr-2" />
                        {resource.phone}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-6">
              <h2 className="text-xl mb-6 flex items-center">
                <MapPin className="w-5 h-5 mr-2" />
                Local Emergency Resources
              </h2>
              
              <div className="space-y-4">
                {localResources.map((resource, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <h3 className="font-medium mb-2">{resource.name}</h3>
                    <p className="text-sm text-muted-foreground mb-3">{resource.description}</p>
                    <p className="text-sm text-blue-600 dark:text-blue-400">{resource.action}</p>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Immediate Coping Strategies */}
          <div className="space-y-6">
            <Card className="p-6">
              <h2 className="text-xl mb-6">Immediate Coping Strategies</h2>
              <p className="text-sm text-muted-foreground mb-6">
                While waiting for professional help, these techniques can help you stay safe:
              </p>
              
              <div className="space-y-4">
                {copingStrategies.map((strategy, index) => (
                  <div key={index} className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <h3 className="font-medium mb-2">{strategy.title}</h3>
                    <p className="text-sm text-muted-foreground">{strategy.description}</p>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-6">
              <h2 className="text-xl mb-4">Online Crisis Chat</h2>
              <p className="text-sm text-muted-foreground mb-6">
                If you prefer to chat online, these resources offer immediate support:
              </p>
              
              <div className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Crisis Text Line Chat
                  <ExternalLink className="w-4 h-4 ml-auto" />
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  National Suicide Prevention Chat
                  <ExternalLink className="w-4 h-4 ml-auto" />
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Trevor Project Chat (LGBTQ+)
                  <ExternalLink className="w-4 h-4 ml-auto" />
                </Button>
              </div>
            </Card>

            <Card className="p-6 bg-green-50 dark:bg-green-900/20 border-green-300 dark:border-green-700">
              <h2 className="text-xl mb-4 text-green-800 dark:text-green-300">
                Remember: You Matter
              </h2>
              <ul className="text-sm space-y-2 text-green-700 dark:text-green-400">
                <li>• This feeling is temporary, even if it doesn't feel that way</li>
                <li>• You have survived difficult times before</li>
                <li>• People care about you and want to help</li>
                <li>• Professional support can make a real difference</li>
                <li>• You deserve to feel better and get the help you need</li>
              </ul>
            </Card>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-12 text-center text-sm text-muted-foreground">
          <p>
            This page provides information about crisis resources. In an emergency, always call 911 or go to your nearest emergency room.
            If you're not in immediate danger but need someone to talk to, please reach out to any of the resources above.
          </p>
        </div>
      </div>
    </div>
  );
}