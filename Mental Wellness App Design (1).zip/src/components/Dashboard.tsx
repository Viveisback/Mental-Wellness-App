import { useState } from "react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { 
  Brain, 
  Heart, 
  MessageCircle, 
  BookOpen, 
  Phone, 
  TrendingUp,
  Calendar,
  Target,
  Zap
} from "lucide-react";

interface DashboardProps {
  assessmentResults: {
    totalScore: number;
    riskLevel: 'low' | 'moderate' | 'high';
    categories: {
      anxiety: number;
      depression: number;
      stress: number;
    };
  };
  onStartChat: () => void;
  onCrisisHelp: () => void;
}

export function Dashboard({ assessmentResults, onStartChat, onCrisisHelp }: DashboardProps) {
  const [selectedGoal, setSelectedGoal] = useState<string | null>(null);

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-600 bg-green-100';
      case 'moderate': return 'text-yellow-600 bg-yellow-100';
      case 'high': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const resources = [
    {
      title: "Understanding Anxiety",
      type: "Article",
      readTime: "5 min",
      category: "Anxiety",
      recommended: assessmentResults.categories.anxiety > 2
    },
    {
      title: "Dealing with Depression",
      type: "Guide",
      readTime: "10 min",
      category: "Depression",
      recommended: assessmentResults.categories.depression > 2
    },
    {
      title: "Stress Management Techniques",
      type: "Video",
      readTime: "8 min",
      category: "Stress",
      recommended: assessmentResults.categories.stress > 2
    },
    {
      title: "Mindfulness Meditation",
      type: "Audio",
      readTime: "15 min",
      category: "Self-Care",
      recommended: true
    }
  ];

  const goals = [
    { id: 'sleep', label: 'Better Sleep', icon: '🌙', progress: 30 },
    { id: 'exercise', label: 'Daily Movement', icon: '🏃', progress: 60 },
    { id: 'mindfulness', label: 'Mindfulness Practice', icon: '🧘', progress: 45 },
    { id: 'social', label: 'Social Connection', icon: '👥', progress: 25 }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-purple-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl mb-2">Welcome back to MindSpace</h1>
          <p className="text-muted-foreground">Here's your personalized wellness dashboard</p>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Button
            onClick={onStartChat}
            className="h-20 flex flex-col items-center justify-center space-y-2 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
          >
            <MessageCircle className="w-6 h-6" />
            <span>Chat with AI Counselor</span>
          </Button>
          
          <Button
            variant="outline"
            className="h-20 flex flex-col items-center justify-center space-y-2 border-2 hover:bg-green-50"
          >
            <BookOpen className="w-6 h-6" />
            <span>Explore Resources</span>
          </Button>
          
          <Button
            onClick={onCrisisHelp}
            variant="destructive"
            className="h-20 flex flex-col items-center justify-center space-y-2"
          >
            <Phone className="w-6 h-6" />
            <span>Crisis Support</span>
          </Button>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
            <TabsTrigger value="goals">Goals</TabsTrigger>
            <TabsTrigger value="progress">Progress</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Assessment Results */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl flex items-center">
                  <Brain className="w-5 h-5 mr-2" />
                  Your Wellness Check-In
                </h2>
                <Badge className={getRiskColor(assessmentResults.riskLevel)}>
                  {assessmentResults.riskLevel} risk
                </Badge>
              </div>
              
              <div className="grid md:grid-cols-3 gap-4 mb-6">
                <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h3 className="text-sm text-muted-foreground mb-1">Anxiety</h3>
                  <div className="text-2xl">{assessmentResults.categories.anxiety}/6</div>
                  <Progress value={(assessmentResults.categories.anxiety / 6) * 100} className="mt-2" />
                </div>
                <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                  <h3 className="text-sm text-muted-foreground mb-1">Depression</h3>
                  <div className="text-2xl">{assessmentResults.categories.depression}/6</div>
                  <Progress value={(assessmentResults.categories.depression / 6) * 100} className="mt-2" />
                </div>
                <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <h3 className="text-sm text-muted-foreground mb-1">Stress</h3>
                  <div className="text-2xl">{assessmentResults.categories.stress}/6</div>
                  <Progress value={(assessmentResults.categories.stress / 6) * 100} className="mt-2" />
                </div>
              </div>

              <div className="bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900 dark:to-blue-900 rounded-lg p-4">
                <h3 className="mb-2">Personalized Recommendation</h3>
                <p className="text-sm text-muted-foreground">
                  Based on your assessment, we recommend starting with stress management techniques 
                  and connecting with our AI counselor for personalized support.
                </p>
              </div>
            </Card>

            {/* Today's Inspiration */}
            <Card className="p-6">
              <h2 className="text-xl mb-4 flex items-center">
                <Heart className="w-5 h-5 mr-2" />
                Today's Inspiration
              </h2>
              <div className="relative">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1655970580622-4a547789c850?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHx8MTc1ODA5NTkxOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Peaceful meditation"
                  className="w-full h-48 object-cover rounded-lg"
                />
                <div className="absolute inset-0 bg-black/40 rounded-lg flex items-center justify-center">
                  <div className="text-center text-white px-4">
                    <p className="text-lg mb-2">"Progress, not perfection."</p>
                    <p className="text-sm opacity-90">Every small step you take matters</p>
                  </div>
                </div>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="resources" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {resources.map((resource, index) => (
                <Card key={index} className="p-6 hover:shadow-lg transition-all">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="mb-2">{resource.title}</h3>
                      <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                        <Badge variant="outline">{resource.type}</Badge>
                        <span>•</span>
                        <span>{resource.readTime}</span>
                      </div>
                    </div>
                    {resource.recommended && (
                      <Badge className="bg-green-100 text-green-800">Recommended</Badge>
                    )}
                  </div>
                  <Button variant="outline" className="w-full">
                    Start Reading
                  </Button>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="goals" className="space-y-6">
            <Card className="p-6">
              <h2 className="text-xl mb-6 flex items-center">
                <Target className="w-5 h-5 mr-2" />
                Your Wellness Goals
              </h2>
              <div className="grid md:grid-cols-2 gap-6">
                {goals.map((goal) => (
                  <div
                    key={goal.id}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedGoal === goal.id 
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedGoal(goal.id)}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <span className="text-2xl">{goal.icon}</span>
                        <span>{goal.label}</span>
                      </div>
                      <span className="text-sm text-muted-foreground">{goal.progress}%</span>
                    </div>
                    <Progress value={goal.progress} className="mb-2" />
                    <Button variant="outline" size="sm" className="w-full">
                      Update Progress
                    </Button>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="progress" className="space-y-6">
            <Card className="p-6">
              <h2 className="text-xl mb-6 flex items-center">
                <TrendingUp className="w-5 h-5 mr-2" />
                Your Progress Journey
              </h2>
              
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <Zap className="w-6 h-6 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <h3>Completed Wellness Check-in</h3>
                    <p className="text-sm text-muted-foreground">Great job taking the first step!</p>
                  </div>
                  <span className="text-sm text-muted-foreground">Today</span>
                </div>

                <div className="flex items-center space-x-4 opacity-50">
                  <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
                    <Calendar className="w-6 h-6 text-gray-400" />
                  </div>
                  <div className="flex-1">
                    <h3>Set your first wellness goal</h3>
                    <p className="text-sm text-muted-foreground">Choose what you'd like to work on</p>
                  </div>
                  <span className="text-sm text-muted-foreground">Upcoming</span>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}