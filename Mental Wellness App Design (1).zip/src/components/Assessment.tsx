import { useState } from "react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Progress } from "./ui/progress";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { Label } from "./ui/label";
import { ArrowLeft, ArrowRight } from "lucide-react";

interface AssessmentProps {
  onComplete: (results: AssessmentResults) => void;
  onBack: () => void;
}

interface AssessmentResults {
  totalScore: number;
  riskLevel: 'low' | 'moderate' | 'high';
  categories: {
    anxiety: number;
    depression: number;
    stress: number;
  };
}

const questions = [
  {
    id: 1,
    category: 'anxiety',
    question: "Over the last 2 weeks, how often have you felt nervous, anxious, or on edge?",
    options: [
      { value: 0, label: "Not at all" },
      { value: 1, label: "Several days" },
      { value: 2, label: "More than half the days" },
      { value: 3, label: "Nearly every day" }
    ]
  },
  {
    id: 2,
    category: 'anxiety',
    question: "Over the last 2 weeks, how often have you been unable to stop or control worrying?",
    options: [
      { value: 0, label: "Not at all" },
      { value: 1, label: "Several days" },
      { value: 2, label: "More than half the days" },
      { value: 3, label: "Nearly every day" }
    ]
  },
  {
    id: 3,
    category: 'depression',
    question: "Over the last 2 weeks, how often have you felt down, depressed, or hopeless?",
    options: [
      { value: 0, label: "Not at all" },
      { value: 1, label: "Several days" },
      { value: 2, label: "More than half the days" },
      { value: 3, label: "Nearly every day" }
    ]
  },
  {
    id: 4,
    category: 'depression',
    question: "Over the last 2 weeks, how often have you had little interest or pleasure in doing things?",
    options: [
      { value: 0, label: "Not at all" },
      { value: 1, label: "Several days" },
      { value: 2, label: "More than half the days" },
      { value: 3, label: "Nearly every day" }
    ]
  },
  {
    id: 5,
    category: 'stress',
    question: "How often have you felt overwhelmed by your responsibilities?",
    options: [
      { value: 0, label: "Never" },
      { value: 1, label: "Sometimes" },
      { value: 2, label: "Often" },
      { value: 3, label: "Almost always" }
    ]
  },
  {
    id: 6,
    category: 'stress',
    question: "How often do you have trouble sleeping due to stress or worry?",
    options: [
      { value: 0, label: "Never" },
      { value: 1, label: "Sometimes" },
      { value: 2, label: "Often" },
      { value: 3, label: "Almost always" }
    ]
  }
];

export function Assessment({ onComplete, onBack }: AssessmentProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});

  const handleAnswer = (value: string) => {
    setAnswers({ ...answers, [questions[currentQuestion].id]: parseInt(value) });
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      // Calculate results
      const totalScore = Object.values(answers).reduce((sum, score) => sum + score, 0);
      const maxScore = questions.length * 3;
      
      const categories = {
        anxiety: questions
          .filter(q => q.category === 'anxiety')
          .reduce((sum, q) => sum + (answers[q.id] || 0), 0),
        depression: questions
          .filter(q => q.category === 'depression')
          .reduce((sum, q) => sum + (answers[q.id] || 0), 0),
        stress: questions
          .filter(q => q.category === 'stress')
          .reduce((sum, q) => sum + (answers[q.id] || 0), 0)
      };

      let riskLevel: 'low' | 'moderate' | 'high' = 'low';
      if (totalScore > maxScore * 0.66) riskLevel = 'high';
      else if (totalScore > maxScore * 0.33) riskLevel = 'moderate';

      onComplete({ totalScore, riskLevel, categories });
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    } else {
      onBack();
    }
  };

  const progress = ((currentQuestion + 1) / questions.length) * 100;
  const currentAnswer = answers[questions[currentQuestion].id];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-purple-900 p-4">
      <div className="container mx-auto max-w-2xl pt-12">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl">Mental Wellness Check-In</h1>
            <span className="text-sm text-muted-foreground">
              {currentQuestion + 1} of {questions.length}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <Card className="p-8 mb-8">
          <div className="mb-8">
            <h2 className="text-xl mb-6">{questions[currentQuestion].question}</h2>
            
            <RadioGroup
              value={currentAnswer?.toString() || ""}
              onValueChange={handleAnswer}
            >
              <div className="space-y-4">
                {questions[currentQuestion].options.map((option) => (
                  <div key={option.value} className="flex items-center space-x-2">
                    <RadioGroupItem value={option.value.toString()} id={option.value.toString()} />
                    <Label htmlFor={option.value.toString()} className="flex-1 cursor-pointer py-2">
                      {option.label}
                    </Label>
                  </div>
                ))}
              </div>
            </RadioGroup>
          </div>

          <div className="flex justify-between">
            <Button variant="outline" onClick={handlePrevious}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              {currentQuestion === 0 ? 'Back' : 'Previous'}
            </Button>
            
            <Button 
              onClick={handleNext} 
              disabled={currentAnswer === undefined}
            >
              {currentQuestion === questions.length - 1 ? 'Complete' : 'Next'}
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </Card>

        <div className="text-center text-sm text-muted-foreground">
          <p>This assessment is confidential and helps us provide personalized support.</p>
          <p>It is not a substitute for professional diagnosis.</p>
        </div>
      </div>
    </div>
  );
}